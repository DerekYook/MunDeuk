package com.together.MunDeuk.web.Admin.repository;

public class AdminCustomRepositoryImpl implements AdminCustomRepository{
}
