package com.together.MunDeuk.web.Member.entity;

public class Member {
}
