package com.together.MunDeuk.web.Board.repository;

public interface BoardCustomRepository {
}
