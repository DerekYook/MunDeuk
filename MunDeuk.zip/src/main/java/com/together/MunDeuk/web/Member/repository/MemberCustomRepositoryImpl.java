package com.together.MunDeuk.web.Member.repository;

public class MemberCustomRepositoryImpl implements MemberCustomRepository {
}
