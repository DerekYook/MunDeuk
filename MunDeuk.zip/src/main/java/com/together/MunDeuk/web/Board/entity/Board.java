package com.together.MunDeuk.web.Board.entity;

public class Board {
}
