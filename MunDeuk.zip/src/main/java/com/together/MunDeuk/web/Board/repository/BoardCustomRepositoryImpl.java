package com.together.MunDeuk.web.Board.repository;

public class BoardCustomRepositoryImpl implements BoardCustomRepository {
}
