package com.together.MunDeuk.web.Member.dto;

public class MemberDto {
}
