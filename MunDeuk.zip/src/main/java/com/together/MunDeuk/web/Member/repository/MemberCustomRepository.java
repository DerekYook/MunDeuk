package com.together.MunDeuk.web.Member.repository;

public interface MemberCustomRepository {
}
