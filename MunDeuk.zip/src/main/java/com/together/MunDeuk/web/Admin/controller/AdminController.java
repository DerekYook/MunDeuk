package com.together.MunDeuk.web.Admin.controller;

public class AdminController {
}
