package com.together.MunDeuk.web.Admin.repository;

public interface AdminCustomRepository {
}
