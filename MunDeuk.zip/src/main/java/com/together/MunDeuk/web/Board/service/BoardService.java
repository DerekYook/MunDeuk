package com.together.MunDeuk.web.Board.service;

public class BoardService {
}
