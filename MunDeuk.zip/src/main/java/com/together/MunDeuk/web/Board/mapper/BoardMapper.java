package com.together.MunDeuk.web.Board.mapper;

public interface BoardMapper {
}
