package com.together.MunDeuk.web.Admin.service;

public class AdminService {
}
