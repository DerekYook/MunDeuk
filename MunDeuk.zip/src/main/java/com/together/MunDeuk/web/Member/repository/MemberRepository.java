package com.together.MunDeuk.web.Member.repository;

public interface MemberRepository extends MemberCustomRepository {
}
