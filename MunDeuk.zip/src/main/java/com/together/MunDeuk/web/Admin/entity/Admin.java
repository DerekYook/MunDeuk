package com.together.MunDeuk.web.Admin.entity;

public class Admin {
}
