package com.together.MunDeuk.web.Board.controller;

public class BoardController {
}
