package com.together.MunDeuk.web.Admin.mapper;

public interface AdminMapper {
}
