package com.together.MunDeuk.web.Member.mapper;

public interface MemberMapper {
}
