package com.together.MunDeuk.web.Admin.dto;

public class AdminDto {
}
