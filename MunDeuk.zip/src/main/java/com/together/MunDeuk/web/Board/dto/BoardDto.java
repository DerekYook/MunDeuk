package com.together.MunDeuk.web.Board.dto;

public class BoardDto {
}
