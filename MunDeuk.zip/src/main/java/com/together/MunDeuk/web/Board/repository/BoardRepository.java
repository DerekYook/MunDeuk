package com.together.MunDeuk.web.Board.repository;

public interface BoardRepository extends BoardCustomRepository{
}
