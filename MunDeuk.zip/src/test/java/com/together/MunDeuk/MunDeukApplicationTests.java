package com.together.MunDeuk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MunDeukApplicationTests {

	@Test
	void contextLoads() {
	}

}
